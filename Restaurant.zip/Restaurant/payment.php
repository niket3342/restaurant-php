<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
        .txt{
            margin-top: 15%;
            text-align: center;
            font-family: 'Courier New', Courier, monospace;
        }
        .btn{
            margin-left: 48%; 
            font-size: larger;  
            background-color: black;
            color: antiquewhite;
        }
        body{
            background: url(image/bg.webp);
            background-size: 100%;
            margin-top: 18%;
        }

    </style>
</head>
<body> 
    <table>
        <h1 class="txt">
            Thank You for Ordering
            <br>
            Your Payment is Successful!
            <br>
            Kindly Wait for your order     
        </h1>
        <button class="btn">Okay</button>
    </table>
</body>
</html>