password :- 
username :- root


create the database with name of follows
database name :- restaurant
