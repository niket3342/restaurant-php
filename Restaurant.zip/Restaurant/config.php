<?php

$conn = mysqli_connect('localhost','root','','restaurant') or die('connection failed');

?>